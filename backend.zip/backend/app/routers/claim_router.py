from fastapi import APIRouter, Depends, HTTPException, status

from app.dependencies import DbSession, get_current_user, get_redis_client
from app.models import User
from app.schemas import ClaimCreate, ClaimResponse
from app.services.claim_service import ClaimService
from app.services.exceptions import AuthorizationError, NotFoundError, ValidationError
from app.services.trigger_engine import TriggerEngine
from app.services.trigger_service import TriggerService

router = APIRouter(prefix="/claims", tags=["Claims"])


@router.get(
    "/",
    response_model=list[ClaimResponse],
    summary="Get my claims",
    description="Returns all claims for the authenticated user, ordered newest first.",
)
async def get_my_claims(session: DbSession, current_user: User = Depends(get_current_user)):
    return await ClaimService(session).get_user_claims(current_user.id)


@router.post(
    "/auto-process",
    status_code=200,
    summary="Auto process claims",
    description="Trigger automatic claim creation for active policies in disrupted zones. Normally called by a cron job.",
)
async def auto_process_claims(session: DbSession, redis=Depends(get_redis_client)):
    trigger_svc = TriggerService(session, redis)
    created_events = await trigger_svc.poll_weather_for_active_users()
    summary = await TriggerEngine(session).run_claim_pipeline()
    return {
        "status": "success",
        "events_detected": created_events,
        "pipeline_summary": summary
    }


@router.post("/submit", response_model=ClaimResponse, status_code=201)
async def submit_claim(claim: ClaimCreate, session: DbSession, current_user: User = Depends(get_current_user)):
    if current_user.id != claim.user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")
    try:
        return await ClaimService(session).submit_claim(claim)
    except NotFoundError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error)) from error
    except AuthorizationError as error:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(error)) from error
    except ValidationError as error:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(error)) from error


@router.get("/user/{user_id}", response_model=list[ClaimResponse])
async def get_user_claims(user_id: int, session: DbSession, current_user: User = Depends(get_current_user)):
    if current_user.id != user_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")
    return await ClaimService(session).get_user_claims(user_id)


@router.get("/{claim_id}", response_model=ClaimResponse)
async def get_claim(claim_id: int, session: DbSession, current_user: User = Depends(get_current_user)):
    try:
        claim = await ClaimService(session).get_claim(claim_id)
    except NotFoundError as error:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(error)) from error
    if claim.user_id != current_user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")
    return claim
